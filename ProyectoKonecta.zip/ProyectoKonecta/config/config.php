<?php

/* Valores de base de datos */
define("DB_HOST", "localhost");
define("DB", "proyectokonecta");
define("DB_USER", "root");
define("DB_PASS", "");

/* Opciones por defecto */
define("DEFAULT_CONTROLLER", "producto");
define("DEFAULT_ACTION", "list");

?>