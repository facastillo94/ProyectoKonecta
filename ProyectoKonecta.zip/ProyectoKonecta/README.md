### Montaje del proyecto realizado
1. Montar servidor LAMP o XAMPP en el equipo (LINUX o WINDOWS)
2. Subir servicios de APACHE y MYSQL
3. Descomprimir carpeta "ProyectoKonecta" en carpeta www o public_html del apache
4. Entrar al servico Mysql (MariaDB), crear base de datos con el nombre que se desee
5. Importar archivo "proyectokonecta.sql" a esta base de datos
6. Entrar a la carpeta "ProyectoKonecta/config", archivo config.php
7. En este archivo, de las lineas 5 a la 7 configurar nombre de base de datos, usuario y contraseña de su servidor
8.  Ya estara listo para ingresar, INGRESO: http://<URL>/ProyectoKonecta/
